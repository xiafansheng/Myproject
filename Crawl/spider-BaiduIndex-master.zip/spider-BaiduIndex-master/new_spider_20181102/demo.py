from new_get_index import main

if __name__ == "__main__":
    demo = main('张艺兴', '2018-01-01', '2018-09-01')
    for data in demo:
        print(data)

